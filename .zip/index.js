class Queue {
    constructor() {
        this.items = [];
    }

    enqueue(element) {
        this.items.push(element);
    }

    dequeue() {
        if (this.isEmpty()) return null;
        return this.items.shift();
    }

    isEmpty() {
        return this.items.length === 0;
    }
}

function isValid(x, y, N, M, grid) {
    return x >= 0 && x < N && y >= 0 && y < M && grid[x][y] !== 0;
}

function horseMoves(x, y, N, M, grid) {
    const moves = [
        [x + 2, y + 1], [x + 2, y - 1], [x - 2, y + 1], [x - 2, y - 1],
        [x + 1, y + 2], [x - 1, y + 2], [x + 1, y - 2], [x - 1, y - 2]
    ];

    return moves.filter(([i, j]) => isValid(i, j, N, M, grid));
}

function bishopMoves(x, y, N, M, grid) {
    const moves = [];
    for (let d = 1; d < Math.min(N - x, M - y); d++) {
        moves.push([x + d, y + d], [x + d, y - d]);
    }
    for (let d = 1; d < Math.min(x + 1, M - y); d++) {
        moves.push([x - d, y + d], [x - d, y - d]);
    }

    return moves.filter(([i, j]) => isValid(i, j, N, M, grid));
}

function findMeetingPoint(N, M, horsePos, bishopPos, inactiveCells) {
    const grid = Array.from({ length: N }, () => Array(M).fill(1));

    inactiveCells.forEach(([i, j]) => {
        grid[i][j] = 0;
    });

    const queue = new Queue();
    queue.enqueue([horsePos, bishopPos]);

    while (!queue.isEmpty()) {
        const [horse, bishop] = queue.dequeue();

        if (horse[0] === bishop[0] && horse[1] === bishop[1]) {
            return horse;
        }

        const horseMovesList = horseMoves(horse[0], horse[1], N, M, grid);
        const bishopMovesList = bishopMoves(bishop[0], bishop[1], N, M, grid);

        for (const hMove of horseMovesList) {
            for (const bMove of bishopMovesList) {
                queue.enqueue([hMove, bMove]);
                grid[hMove[0]][hMove[1]] = 0;
                grid[bMove[0]][bMove[1]] = 0;
            }
        }
    }

    return null;
}

function drawGrid(N, M, horsePos, bishopPos, meetingPoint) {
    const gridContainer = document.getElementById('grid-container');
    gridContainer.style.setProperty('--cols', M);

    for (let i = 0; i < N; i++) {
        for (let j = 0; j < M; j++) {
            const cell = document.createElement('div');
            cell.className = 'cell';

            if (i === bishopPos[0] && j === bishopPos[1]) {
                cell.classList.add('bishop');
            } else if (i === horsePos[0] && j === horsePos[1]) {
                cell.classList.add('horse');
            } else if (meetingPoint && i === meetingPoint[0] && j === meetingPoint[1]) {
                cell.classList.add('meeting-point');
            } else if (inactiveCells.some(([x, y]) => x === i && y === j)) {
                cell.classList.add('inactive');
            }

            gridContainer.appendChild(cell);
        }
    }
}

const N = 8;
const M = 8;
const horsePosition = [6, 6];
const bishopPosition = [3, 2];
const inactiveCells = [[0, 3], [2, 0]];

const meetingPoint = findMeetingPoint(N, M, horsePosition, bishopPosition, inactiveCells);

drawGrid(N, M, horsePosition, bishopPosition, meetingPoint);
